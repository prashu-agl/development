<?php


#Nss Camp Post Type COde Start.
function NssCampPostTypeRegister()
{
	$labels = array(
		'name'                  => 'NssCamp',
		'singular_name'         => 'NssCamp',
		'menu_name'             => 'NssCamp',
		'name_admin_bar'        => 'NssCamp',
		'add_new'               => 'Add New NssCamp',
		'add_new_item'          => 'Add New NssCamp',
		'new_item'              => 'New NssCamp',
		'edit_item'             => 'Edit NssCamp',
		'view_item'             => 'View NssCamp',
		'all_items'             => 'All NssCamp',
		'search items'          => 'Search NssCamp',
		'parent_item_colon'     => 'Parent NssCamp',
		'not_found'             => 'No NssCamp Found',
		'not_found_in_trash'    => 'No NssCamp Found In Trash',
	);

	$args = array(
		'labels'                => $labels,
		'public'                => true,
		'publicaly_queryable'   => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'query_var'             => true,
		'rewrite'               => array( 'slug' => 'nsscamp' ),
		'capability_type'       => 'post',
		'has_archive'           => true,
		'Hierarchical'          => false,
		'menu_position'         => null,
		'menu_icon'             => 'dashicons-format-image',
		'supports'              => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments','hierarchical','trackbacks','custom-fields','revisions','page-attributes'),
	);
	register_post_type('NssCamp',$args);
}
add_action('init','NssCampPostTypeRegister');
#Nss Camp Post Type Code end.




 		add_action( 'load-post.php', 'campMetaBoxSetup');
    add_action( 'load-post-new.php', 'campMetaBoxSetup');
    add_action( 'save_post', 'campMetaBoxSaveData', 10, 2 );
    function campMetaBoxSetup() {
        add_action( 'add_meta_boxes', 'campMetaBoxAdd');
    }
    function campMetaBoxAdd() {
        add_meta_box('camp_start_date',__( 'Camp Start Date' ),'campMetaBox','nsscamp','side','high');
    }
    function campMetaBox( $post ) {
        wp_nonce_field( basename( __FILE__ ), 'ann_meta_boxes_nonce' ); ?>
        <label for="meta-box-start-date"><?php _e( 'Start Date'); ?></label>
    		<input type="date" id="meta-box-start-date" name="meta-box-start-date" value="<?php echo get_post_meta( $post->ID, 'camp_start_date', true); ?>" >
        <?php
    }
    function campMetaBoxSaveData( $post_id, $post ) {
        if ( !isset( $_POST['ann_meta_boxes_nonce'] ) || !wp_verify_nonce( $_POST['ann_meta_boxes_nonce'], basename( __FILE__ ) ) )
        return $post_id;
        $post_type = get_post_type_object( $post->post_type );
        if ( !current_user_can( $post_type->cap->edit_post, $post_id ) )
        return $post_id;
        $meta_box_start_date = '';
        if( isset( $_POST["meta-box-start-date"] ) ) {
        $meta_box_start_date = $_POST["meta-box-start-date"];
        }
        update_post_meta( $post_id, "camp_start_date", $meta_box_start_date );
    }
    function campMetaBoxDateClass( $classes ) {
        global $post;
        if ( get_post_meta( $post->ID, 'camp_start_date' ) &&  get_post_meta( $post->ID, 'camp_start_date', true ) == 'yes' ) {
        $classes[] = 'camp-start-date';
        }
        return $classes;
    }
    add_filter( 'post_class', 'campMetaBoxDateClass' ); 



function req_meta_wpse_96762($data){
  $allow_pending = false;
  if (isset($_POST['meta-box-start-date'])) {
      if ( !empty($_POST['meta-box-start-date'])) {
        $allow_pending = true;
      }
  }
  if (false === $allow_pending) {
    $data['post_status'] = 'draft';

  }
  return $data;
}
add_action('wp_insert_post_data','req_meta_wpse_96762');



#Nss Camp Listing Page Code Start.
function NssCampLoadMore() {
   $wp_posts = new WP_Query( array( 
			'post_type' => 'nsscamp',
			'post_status' => 'publish', 
			// 'tax_query' => array(                                        
			// 		array(
			// 				'taxonomy'         => 'post-categories',
			// 				'field'            => 'slug',											
			// 				'terms'            => 'blog',
			// 		),
			// 	),
			'posts_per_page' => 9,
			'paged' => $_POST['paged'],					
			'orderby' => 'date',
			'order' =>'DESC'
		) 
	);

  $response = '';

  if ( $wp_posts->have_posts() ) {
	while ( $wp_posts->have_posts() ) {
		$wp_posts->the_post();
		$postid = get_the_ID();
		$blog_title = get_the_title();
        $blog_permalink = get_permalink();
        $blog_excerpt = get_the_excerpt();
        $blog_date = get_the_date();
		$image = wp_get_attachment_image_src(get_post_thumbnail_id($postid), 'full');
        $response .=  '<div class="event-inner aos-init aos-animate" data-aos="fade-up" data-aos-delay="100">
							<div class="about-page-section4-right-slider-inner">
								<a href="'.$blog_permalink.'">
								    <div class="about-page-section4-right-slider-th">
									    <img src="'.$image[0].'">
								    </div>
								</a>
								<div class="about-page-section4-right-slider-caption">
									<a href="'.$blog_permalink.'"><h4>'.$blog_title.'</h4></a>
									<div class="date-share-box">
										<span>'.$blog_date.'</span>
										<div class="blog-share">
											<ul class="blog-list">
												<li><a href="javascript:;">Share on</a></li>											
												<li><a rel="nofollow" href="http://www.facebook.com/share.php?u='.$blog_permalink.'" onclick="return fbs_click()" target="_blank"><img src="https://www.narayanseva.org/wp-content/themes/nss/assets/images/s-fb.png"/></a></li>
												<li><a type="button" role="button" title="Share on twitter" href="https://twitter.com/intent/tweet?url='.$blog_permalink.'" rel="noopener"><img src="https://www.narayanseva.org/wp-content/themes/nss/assets/images/s-tw.png"/></a></li>
												<li><a href="https://www.linkedin.com/shareArticle?mini=true&url='.$blog_permalink.'&title=&summary=&source=" onclick="window.open(this.href, \'mywin\',\'left=20,top=20,width=500,height=500,toolbar=1,resizable=0\'); return false;" ><img src="https://www.narayanseva.org/wp-content/themes/nss/assets/images/s-lin.png"/></a></li>
											</ul>
										</div>
									</div>
									<p>'.$blog_excerpt.'</p>
									<p><a href="'.$blog_permalink.'">Read more...</a></p>
								</div>
							</div>
						</div>';
    }
  } else {
    $response = '<h4 style="width: 200px;margin: 0 auto;padding: 20px 0 30px;">No results found</h4>';
  }
  wp_reset_postdata();

  echo $response;
  exit;
}
add_action('wp_ajax_NssCampLoadMore', 'NssCampLoadMore');
add_action('wp_ajax_nopriv_NssCampLoadMore', 'NssCampLoadMore');



#Nss Camp Post user list Code Start.
if(is_admin()){
	new Paulund_Wp_List_Table();
}
class Paulund_Wp_List_Table{
	public function __construct(){
		add_action( 'admin_menu', array($this, 'NssCampUserTable' ));
	}
	public function NssCampUserTable(){
		add_menu_page( 'NssCamp User List', 'NssCamp User List', 'manage_options', 'nsscamp_user_list', array($this, 'list_table_page'),'',6 );
	}
	public function list_table_page(){
		$clintListTable = new Clint_List_Table();
		$clintListTable->prepare_items();
		?>
		<div class="wrap">
			<div id="icon-users" class="icon32"></div>
			<h2>NssCamp User List</h2>
			<?php $clintListTable->display(); ?>
		</div>
		<?php
	}
}
if( ! class_exists( 'WP_List_Table' ) ) {
	require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}
class Clint_List_Table extends WP_List_Table {
	public function prepare_items(){
		$columns = $this->get_columns();
		$hidden = $this->get_hidden_columns();
		$sortable = $this->get_sortable_columns();
		$data = $this->table_data();
		usort( $data, array( &$this, 'sort_data' ) );
		$perPage = 10;
		$currentPage = $this->get_pagenum();
		$totalItems = count($data);
		$this->set_pagination_args( array(
			'total_items' => $totalItems,
			'per_page'    => $perPage
		) );
		$data = array_slice($data,(($currentPage-1)*$perPage),$perPage);
		$this->_column_headers = array($columns, $hidden, $sortable);
		$this->items = $data;
	}
	public function get_columns(){
		$columns = array(
			'id'                    => 'ID',
			'nsscamppostid'         => 'Camp Post Id',
			'fname'                 => 'First Name',
			'lname'                 => 'Last Name',
			'email'                 => 'Email',
			'phone'                 => 'Phone',
			'address'               => 'Address',
			'city'                  => 'City',
			'state'                 => 'State',
			'zip'                   => 'zip'
		);
		return $columns;
	}
	public function get_hidden_columns(){
		return array();
	}
	public function get_sortable_columns(){
		return array('title' => array('title', false));
	}
	private function table_data(){
		$data = array();
		global $wpdb;
		$table_name= 'ns_nsscamp_user_list';
		$resul = $wpdb->get_results( "SELECT * FROM $table_name ORDER BY id ASC");
		foreach ($resul as $key => $value) {
			$data[] = array(
				'id'                => $value->id,
				'nsscamppostid'     => $value->nsscamppostid,
				'fname'             => $value->fname,
				'lname'             => $value->lname,
				'email'             => $value->email,
				'phone'             => $value->phone,
				'address'           => $value->address, 
				'city'              => $value->city, 
				'state'             => $value->state,
				'zip'               => $value->zip
			);
		}
		return $data;
	}
	public function column_default( $item, $column_name ){
		switch( $column_name ) {
			case 'id':
			case 'nsscamppostid':
			case 'fname':
			case 'lname':
			case 'email':
			case 'phone':
			case 'address':
			case 'city':
			case 'state':
			case 'zip':
			return $item[ $column_name ];
			default:
			return print_r( $item, true ) ;
		}
	}

}
#Nss Camp Post user list Code end.

function nssCampIdUn() {
    add_meta_box('nssuniqid', 'Nss Camp Id','wpd_render_meta_box','nsscamp');
}
add_action( 'add_meta_boxes', 'nssCampIdUn' );

function wpd_render_meta_box( $post ) {

    echo '<input type="text" id="nssuniqid" name="nssuniqid" value="' . $post->ID . '">';
}

function nssCampuId( $post_id ) {
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) 
        return $post_id;

    if ( ! isset( $_POST['nssuniqid'] ) )
        return $post_id;

    $sku = $_POST['nssuniqid'];
    update_post_meta( $post_id, 'nssuniqid', $sku );
}
add_action( 'save_post', 'nssCampuId' );